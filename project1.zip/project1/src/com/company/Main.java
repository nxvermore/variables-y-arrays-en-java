package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
       int numero1 = 28;
       numero1 = numero1 + 20;
        System.out.println(numero1);

       String miarray[] = {"pepe","villuela","es","un","hombre","guapeton"};
        System.out.println(miarray[0]);
    }
}
